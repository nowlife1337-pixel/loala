import telebot
import random
import string
import json
import os
from datetime import datetime, timedelta

# ===== ЗАМЕНИ ЭТО НА СВОЙ ТОКЕН =====
API_TOKEN = '8708017520:AAFUc1q9bdgtt4bNWUTBv_MSHLRN9KB8tAc'
# =====================================

bot = telebot.TeleBot(API_TOKEN)
KEYS_FILE = 'keys.json'

def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_keys(keys):
    with open(KEYS_FILE, 'w') as f:
        json.dump(keys, f, indent=2)

def generate_key():
    chars = string.ascii_uppercase + string.digits
    return 'GOS-' + ''.join(random.choice(chars) for _ in range(16))

def is_key_valid(key_data):
    if not key_data:
        return False
    expiry = datetime.fromisoformat(key_data['expiry'])
    return datetime.now() < expiry

def clean_expired_keys():
    keys = load_keys()
    expired = [k for k, v in keys.items() if not is_key_valid(v)]
    for k in expired:
        del keys[k]
    save_keys(keys)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(
        message.chat.id,
        "Добро пожаловать в сервис «Документы в одном клике»!\n\n"
        "Я выдаю ключи доступа к личному кабинету.\n\n"
        "Команды:\n"
        "/buy — купить ключ (на 24 часа)\n"
        "/status — проверить статус ключа\n"
        "/help — помощь"
    )

@bot.message_handler(commands=['buy'])
def buy_key(message):
    clean_expired_keys()
    keys = load_keys()
    user_id = str(message.from_user.id)

    for key, data in keys.items():
        if data.get('user_id') == user_id and is_key_valid(data):
            expiry = datetime.fromisoformat(data['expiry'])
            remaining = expiry - datetime.now()
            hours = int(remaining.total_seconds() // 3600)
            bot.send_message(
                message.chat.id,
                f"У вас уже есть активный ключ!\n"
                f"Осталось: {hours} ч.\n"
                f"Ключ: {key}"
            )
            return

    new_key = generate_key()
    expiry = datetime.now() + timedelta(hours=24)

    keys[new_key] = {
        'user_id': user_id,
        'created': datetime.now().isoformat(),
        'expiry': expiry.isoformat(),
        'active': True
    }

    save_keys(keys)

    bot.send_message(
        message.chat.id,
        f"Ключ приобретён!\n\n"
        f"Ваш ключ: {new_key}\n"
        f"Действует 24 часа (до {expiry.strftime('%d.%m.%Y %H:%M')})\n\n"
        f"Вставьте этот ключ в личном кабинете на сайте."
    )

@bot.message_handler(commands=['status'])
def status(message):
    clean_expired_keys()
    keys = load_keys()
    user_id = str(message.from_user.id)

    for key, data in keys.items():
        if data.get('user_id') == user_id and is_key_valid(data):
            expiry = datetime.fromisoformat(data['expiry'])
            remaining = expiry - datetime.now()
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            bot.send_message(
                message.chat.id,
                f"Ключ активен: {key}\n"
                f"Осталось: {hours} ч. {minutes} мин."
            )
            return

    bot.send_message(message.chat.id, "У вас нет активного ключа.\nИспользуйте /buy для покупки.")

@bot.message_handler(commands=['help'])
def help_cmd(message):
    bot.send_message(
        message.chat.id,
        "Помощь\n\n"
        "/buy — купить ключ доступа на 24 часа\n"
        "/status — проверить статус ключа\n"
        "/start — главное меню\n\n"
        "После получения ключа вставьте его на сайте в разделе «Настройки»."
    )

print('Бот запущен...')
bot.polling(none_stop=True)