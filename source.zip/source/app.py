from flask import Flask, request, jsonify
from datetime import datetime
import json
import os

app = Flask(__name__)

KEYS_FILE = '/home/nowlife/keys.json'

def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, 'r') as f:
            return json.load(f)
    return {}

def is_key_valid(key):
    keys = load_keys()
    if key not in keys:
        return False
    key_data = keys[key]
    expiry = datetime.fromisoformat(key_data['expiry'])
    return datetime.now() < expiry

@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = '*'
    response.headers['Access-Control-Allow-Methods'] = '*'
    return response

@app.route('/check_key')
def check_key():
    key = request.args.get('key', '')
    if not key:
        return jsonify({'valid': False}), 400
    if is_key_valid(key):
        return jsonify({'valid': True})
    return jsonify({'valid': False}), 403

@app.route('/health')
def health():
    return jsonify({'status': 'ok'})